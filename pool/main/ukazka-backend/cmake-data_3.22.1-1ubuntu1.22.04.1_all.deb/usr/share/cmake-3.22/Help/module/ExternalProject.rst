.. cmake-module:: ../../Modules/ExternalProject.cmake

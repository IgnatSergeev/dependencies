.. cmake-module:: ../../Modules/FindPkgConfig.cmake

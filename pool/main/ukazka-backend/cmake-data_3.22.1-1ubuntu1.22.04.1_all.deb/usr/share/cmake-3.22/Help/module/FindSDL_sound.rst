.. cmake-module:: ../../Modules/FindSDL_sound.cmake
